<?php

function pmwi_wp_loaded() {			
	
	
}